#include "a2.h"

// default constructor
SICXE_Instruction::SICXE_Instruction() {
    addr = objcode = NULL;
}
