#include "a2.h"

// default constructor
SICXE_Source::SICXE_Source() {
    start = end = NULL;
}
